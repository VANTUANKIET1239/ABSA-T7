"""Apply the manually reviewed decisions for the original 95 empty ABSA labels.

No automatic text classification. No rows are deleted. Decisions and reasons
are stored in data/empty_label_review_decisions.json.
"""

import csv
import hashlib
import io
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from label_distribution import parse_label
from manual_absa_batches import parse


DATA = Path(__file__).resolve().parent / "data"
TARGET = DATA / "unique_texts_gemini_labeled.csv"
DECISIONS = DATA / "empty_label_review_decisions.json"
BACKUP = DATA / "unique_texts_gemini_labeled.csv.before_empty_review.bak"


def write_report(name, records, fields):
    with (DATA / name).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)


def main():
    decisions = json.loads(DECISIONS.read_text(encoding="utf-8"))
    raw = TARGET.read_bytes()
    records, original_chunks = parse(raw)
    chunks = original_chunks.copy()
    header = records[0]
    ix = {name: header.index(name) for name in header}
    empty_ids = {r[ix["absa_row_id"]] for r in records[1:] if not r[ix["gemini_label"]].strip()}
    actions = {"label", "preserve_existing", "keep_empty", "needs_review", "deletion_candidate"}
    assert all(d["action"] in actions for d in decisions.values())
    expected_empty = {i for i, d in decisions.items() if d["action"] != "preserve_existing"}
    assert empty_ids == expected_empty, "CSV changed; re-review before applying"
    assert not BACKUP.exists(), "Review already applied or backup exists; do not overwrite"
    audit = []
    changed_indices = []
    seen = set()
    for index, row in enumerate(records[1:], 1):
        row_id = row[ix["absa_row_id"]]
        if row_id not in decisions:
            continue
        assert row_id not in seen
        seen.add(row_id)
        decision = decisions[row_id]
        label = decision["label"]
        parse_label(label)
        before_label = row[ix["gemini_label"]]
        if decision["action"] == "label":
            assert before_label == "" and label
            assert row[ix["absa_status"]] == "done"
            updated = row.copy()
            updated[ix["gemini_label"]] = label
            buffer = io.StringIO(newline="")
            ending = "\r\n" if original_chunks[index].endswith(b"\r\n") else "\n"
            csv.writer(buffer, quoting=csv.QUOTE_ALL, lineterminator=ending).writerow(updated)
            chunks[index] = buffer.getvalue().encode("utf-8")
            changed_indices.append(index)
        elif decision["action"] == "preserve_existing":
            assert before_label, "Existing label disappeared"
            label = before_label
        else:
            assert not label
        audit.append({**dict(zip(header, row)),
                      "review_action": decision["action"],
                      "label_after_review": label,
                      "review_reason": decision["reason"]})
    assert seen == set(decisions)
    result = b"".join(chunks)
    after, after_chunks = parse(result)
    assert len(after) == len(records) and after[0] == header
    assert [i for i in range(len(records)) if records[i] != after[i]] == changed_indices
    for index in range(1, len(records)):
        assert all(records[index][column] == after[index][column]
                   for column in range(len(header)) if column != ix["gemini_label"])
        parse_label(after[index][ix["gemini_label"]])
        if index not in changed_indices:
            assert original_chunks[index] == after_chunks[index]
    assert all(row[ix["absa_status"]] == "done" for row in after[1:])
    assert TARGET.read_bytes() == raw, "CSV changed during review; aborting"
    with BACKUP.open("xb") as stream:
        stream.write(raw)
    temporary = TARGET.with_name(TARGET.name + ".review.tmp")
    temporary.write_bytes(result)
    assert TARGET.read_bytes() == raw, "CSV changed before replace; aborting"
    os.replace(temporary, TARGET)
    assert TARGET.read_bytes() == result
    fields = header + ["review_action", "label_after_review", "review_reason"]
    write_report("empty_label_review_audit.csv", audit, fields)
    write_report("empty_label_deletion_candidates.csv",
                 [r for r in audit if r["review_action"] == "deletion_candidate"], fields)
    write_report("empty_label_needs_review.csv",
                 [r for r in audit if r["review_action"] == "needs_review"], fields)
    summary = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "decision_sha256": hashlib.sha256(DECISIONS.read_bytes()).hexdigest(),
        "sha256_before": hashlib.sha256(raw).hexdigest(),
        "sha256_after": hashlib.sha256(result).hexdigest(),
        "rows": len(after) - 1,
        "actions": dict(Counter(d["action"] for d in decisions.values())),
        "updated_row_ids": [records[i][ix["absa_row_id"]] for i in changed_indices],
        "empty_before": len(empty_ids),
        "empty_after": sum(not r[ix["gemini_label"]] for r in after[1:]),
        "rows_deleted": 0,
        "other_fields_and_untouched_records_unchanged": True,
    }
    (DATA / "empty_label_review_log.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
