"""Persist manually reviewed ABSA batches; never infer labels from review text."""
import csv
import hashlib
import io
import json
import os
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'data/unique_texts_gemini_labeled.csv'
BACKUP = TARGET.with_suffix('.csv.before_manual_absa.bak')
LOG = ROOT / 'data/manual_absa_batches.jsonl'
ASPECTS = ['CleansingEffectiveness', 'HydrationSkinComfort', 'SkinCompatibilitySafety',
           'TextureFoaming', 'Fragrance', 'IngredientsFormulation', 'Packaging',
           'PriceValue', 'ShopService', 'Delivery', 'General']
SENTIMENTS = {'p': 'positive', 'n': 'negative', 'u': 'neutral'}


def parse(raw):
    text = raw.decode('utf-8-sig')
    lines = text.splitlines(keepends=True)
    reader = csv.reader(lines)
    records, chunks = [], []
    start = 0
    for record in reader:
        records.append(record)
        chunks.append(''.join(lines[start:reader.line_num]).encode('utf-8'))
        start = reader.line_num
    if raw.startswith(b'\xef\xbb\xbf'):
        chunks[0] = b'\xef\xbb\xbf' + chunks[0]
    return records, chunks


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['read', 'apply', 'verify'])
    parser.add_argument('payload', nargs='?')
    args = parser.parse_args()
    raw = TARGET.read_bytes()
    records, chunks = parse(raw)
    header = records[0]
    ix = {name: header.index(name) for name in header}
    pending = [i for i, r in enumerate(records[1:], 1) if r[ix['absa_status']] == 'pending']
    if args.action == 'verify':
        original, original_chunks = parse(BACKUP.read_bytes())
        assert len(original) == len(records) and original[0] == header
        logs = [json.loads(line) for line in LOG.read_text(encoding='utf-8').splitlines()]
        logged_ids = [row_id for entry in logs for row_id in entry['row_ids']]
        assert len(logged_ids) == len(set(logged_ids))
        changed_ids = []
        empty = 0
        for i, row in enumerate(records[1:], 1):
            before = original[i]
            if before == row:
                assert original_chunks[i] == chunks[i]
                continue
            assert before[ix['absa_status']] == 'pending' and row[ix['absa_status']] == 'done'
            assert all(row[ix[k]] == before[ix[k]] for k in header if k not in ('gemini_label', 'absa_status'))
            changed_ids.append(row[ix['absa_row_id']])
            label = row[ix['gemini_label']]
            if not label:
                empty += 1
                continue
            pairs = []
            for item in label.split(';'):
                assert item.startswith('{') and item.endswith('}')
                aspect, sentiment = item[1:-1].split('#')
                assert aspect in ASPECTS and sentiment in SENTIMENTS.values()
                pairs.append((ASPECTS.index(aspect), sentiment))
            assert len(set(pairs)) == len(pairs)
            assert pairs == sorted(pairs, key=lambda pair: pair[0])
        assert changed_ids == logged_ids
        assert all(entry['updated'] == len(entry['row_ids']) for entry in logs)
        assert all(a['sha256_after'] == b['sha256_before'] for a, b in zip(logs, logs[1:]))
        assert logs[-1]['sha256_after'] == hashlib.sha256(raw).hexdigest()
        print(json.dumps({'batches': len(logs), 'updated': len(changed_ids), 'empty_labels': empty,
                          'pending': len(pending), 'done': len(records)-1-len(pending),
                          'original_done_unchanged': True, 'all_other_fields_unchanged': True,
                          'label_format_valid': True, 'log_chain_valid': True}))
        return
    if args.action == 'read':
        print('pending:', len(pending))
        for i in pending[:100]:
            r = records[i]
            print(r[ix['absa_row_id']] + '\t' + r[ix['cleaned_comment']])
        return
    payload = json.loads(Path(args.payload).read_text(encoding='utf-8-sig'))
    expected = {records[i][ix['absa_row_id']] for i in pending[:100]}
    assert set(payload) == expected, 'Must label exactly the next batch of up to 100 pending rows'
    if not BACKUP.exists():
        with BACKUP.open('xb') as f:
            f.write(raw)
    updated = []
    for i in pending[:100]:
        row = records[i].copy()
        row_id = row[ix['absa_row_id']]
        codes = payload[row_id].split()
        pairs = [(int(code[:-1]), code[-1]) for code in codes]
        assert len(set(pairs)) == len(pairs)
        assert pairs == sorted(pairs, key=lambda pair: pair[0])
        label = ';'.join('{' + ASPECTS[a-1] + '#' + SENTIMENTS[s] + '}' for a, s in pairs if 1 <= a <= 11)
        assert len(pairs) == sum(1 for a, s in pairs if 1 <= a <= 11)
        row[ix['gemini_label']] = label
        row[ix['absa_status']] = 'done'
        stream = io.StringIO(newline='')
        ending = '\r\n' if chunks[i].endswith(b'\r\n') else '\n'
        csv.writer(stream, quoting=csv.QUOTE_ALL, lineterminator=ending).writerow(row)
        chunks[i] = stream.getvalue().encode('utf-8')
        updated.append(i)
    result = b''.join(chunks)
    after, after_chunks = parse(result)
    assert len(after) == len(records)
    changed = [i for i in range(len(records)) if records[i] != after[i]]
    assert changed == updated
    for i in range(1, len(records)):
        for name in header:
            if i in updated and name in ('gemini_label', 'absa_status'):
                continue
            assert records[i][ix[name]] == after[i][ix[name]], (i, name)
    original_chunks = parse(raw)[1]
    assert all(original_chunks[i] == after_chunks[i] for i in range(len(records)) if i not in updated)
    temp = TARGET.with_suffix('.csv.tmp')
    temp.write_bytes(result)
    assert temp.read_bytes() == result
    os.replace(temp, TARGET)
    assert TARGET.read_bytes() == result
    entry = {'timestamp_utc': datetime.now(timezone.utc).isoformat(),
             'updated': len(updated), 'row_ids': [records[i][ix['absa_row_id']] for i in updated],
             'empty_labels': sum(not after[i][ix['gemini_label']] for i in updated),
             'pending_before': len(pending), 'pending_after': len(pending)-len(updated),
             'sha256_before': hashlib.sha256(raw).hexdigest(),
             'sha256_after': hashlib.sha256(result).hexdigest(),
             'verified_other_fields_and_untouched_records': True}
    with LOG.open('a', encoding='utf-8') as f:
        f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    print(json.dumps(entry, ensure_ascii=False))


if __name__ == '__main__':
    main()
