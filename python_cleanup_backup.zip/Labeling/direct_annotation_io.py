"""Select, validate and commit batches that the assistant has annotated directly.

This utility does not classify reviews and never calls a model/API.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'data' / 'unique_texts_gemini_labeled.csv'
LOG_DIR = BASE / 'data' / 'manual_batches'
ASPECTS = ['CleansingEffectiveness', 'HydrationSkinComfort', 'SkinCompatibilitySafety',
           'TextureFoaming', 'Fragrance', 'IngredientsFormulation', 'Packaging',
           'PriceValue', 'ShopService', 'Delivery', 'General']
CODES = dict(zip('CHSTFIPVRDG', ASPECTS))
SENTIMENTS = {'+': 'positive', '0': 'neutral', '-': 'negative'}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def replace_verified(temporary: Path, destination: Path):
    """Prefer atomic replacement; retain rollback data if Windows denies rename."""
    try:
        os.replace(temporary, destination)
    except PermissionError:
        if not destination.is_file():
            raise
        replacement = temporary.read_bytes()
        original = destination.read_bytes()
        # Some Windows hosts allow updating an open file but disallow replacing
        # its directory entry. Keep its permissions and restore on write failure.
        with destination.open('r+b') as handle:
            if handle.read() != original:
                raise RuntimeError('Destination changed before in-place save')
            try:
                handle.seek(0)
                handle.write(replacement)
                handle.truncate()
                handle.flush()
                os.fsync(handle.fileno())
                handle.seek(0)
                if handle.read() != replacement:
                    raise RuntimeError('In-place save verification failed')
            except BaseException:
                handle.seek(0)
                handle.write(original)
                handle.truncate()
                handle.flush()
                os.fsync(handle.fileno())
                raise
        try:
            temporary.unlink()
        except PermissionError:
            pass


def read_csv(path: Path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        headers = reader.fieldnames
    if not headers or len(headers) != len(set(headers)):
        raise ValueError('Invalid or duplicate CSV columns')
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError('Malformed CSV row')
    return headers, rows


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    replace_verified(temporary, path)


def select(snapshot: Path, limit: int):
    original = SOURCE.read_bytes()
    headers, rows = read_csv(SOURCE)
    if len({row['absa_row_id'] for row in rows}) != len(rows):
        raise ValueError('Duplicate row IDs')
    pending = [row for row in rows if row['absa_status'] == 'pending'][:limit]
    if sha(SOURCE.read_bytes()) != sha(original):
        raise RuntimeError('CSV changed while reading; retry selection')
    data = {'source_file': str(SOURCE), 'source_sha256': sha(original),
            'headers': headers, 'row_count': len(rows), 'records': pending}
    write_json(snapshot, data)
    print(json.dumps({'statuses': dict(Counter(r['absa_status'] for r in rows)),
                      'selected': len(pending), 'snapshot': str(snapshot)}, ensure_ascii=False))
    for row in pending:
        print(json.dumps({'id': row['absa_row_id'], 'text': row['cleaned_comment']}, ensure_ascii=False))


def prepare(snapshot: Path, decisions: Path, payload_path: Path):
    selected = json.loads(snapshot.read_text(encoding='utf-8'))
    manual = json.loads(decisions.read_text(encoding='utf-8'))
    if set(manual) != {r['absa_row_id'] for r in selected['records']}:
        raise ValueError('Direct decisions must cover exactly the selected reviews')
    records = []
    for row in selected['records']:
        item = manual[row['absa_row_id']]
        codes = item['codes'].split()
        if len(set(codes)) != len(codes):
            raise ValueError('Duplicate labels')
        pairs = []
        for code in codes:
            if len(code) != 2 or code[0] not in CODES or code[1] not in SENTIMENTS:
                raise ValueError('Invalid annotation code: ' + code)
            pairs.append((CODES[code[0]], SENTIMENTS[code[1]]))
        pairs.sort(key=lambda p: (ASPECTS.index(p[0]), list(SENTIMENTS.values()).index(p[1])))
        label = ';'.join('{' + aspect + '#' + sentiment + '}' for aspect, sentiment in pairs)
        records.append({'absa_row_id': row['absa_row_id'], 'text_group_id': row['text_group_id'],
                        'cleaned_comment': row['cleaned_comment'], 'gemini_label': label,
                        'review_note': item.get('note', '')})
    payload = {**selected, 'records': records, 'annotator': 'assistant_direct',
               'text_column': 'cleaned_comment', 'count': len(records)}
    write_json(payload_path, payload)
    print(json.dumps({'payload': str(payload_path), 'count': len(records),
                      'empty_labels': sum(not r['gemini_label'] for r in records)}))


def commit(payload_path: Path):
    payload = json.loads(payload_path.read_text(encoding='utf-8'))
    if Path(payload['source_file']).resolve() != SOURCE.resolve():
        raise ValueError('Unexpected source path')
    records = payload['records']
    first, last = records[0]['absa_row_id'], records[-1]['absa_row_id']
    if not first.isdigit() or not last.isdigit():
        raise ValueError('Invalid IDs')
    temporary = SOURCE.with_name(SOURCE.name + f'.direct_{first}_{last}.tmp')
    if not temporary.resolve().is_relative_to(BASE.resolve()):
        raise ValueError('Invalid temporary path')
    original = SOURCE.read_bytes()
    if sha(original) != payload['source_sha256']:
        raise RuntimeError('CSV changed since selection; preserve existing work and select again')
    headers, before = read_csv(SOURCE)
    new_headers, after = read_csv(temporary)
    if headers != new_headers or len(before) != len(after):
        raise ValueError('CSV shape changed')
    by_id = {row['absa_row_id']: row for row in records}
    changed = 0
    for old, new in zip(before, after):
        annotation = by_id.get(old['absa_row_id'])
        expected = old.copy()
        if annotation is not None:
            if old['absa_status'] != 'pending' or old['gemini_label']:
                raise ValueError('Refusing to overwrite existing labels')
            if any(old[key] != annotation[key] for key in ('text_group_id', 'cleaned_comment')):
                raise ValueError('Review identity changed')
            expected.update(gemini_label=annotation['gemini_label'], absa_status='done')
            changed += 1
        if new != expected:
            raise ValueError('Unexpected change to CSV data')
    if changed != len(records) or not 0 < changed <= 100:
        raise ValueError('Invalid number of changed rows')
    LOG_DIR.mkdir(exist_ok=True)
    state_path = LOG_DIR / 'direct_goal_progress.json'
    state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else None
    if state is None:
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        backup = SOURCE.with_name(SOURCE.stem + f'.before_direct_goal_{stamp}.csv')
        with backup.open('xb') as handle:
            handle.write(original)
        state = {'initial_backup': str(backup), 'batches': [], 'direct_rows': 0}
    audit_path = LOG_DIR / f'direct_{first}_{last}.json'
    if audit_path.exists():
        raise ValueError('Batch audit already exists')
    if sha(SOURCE.read_bytes()) != sha(original):
        raise RuntimeError('Concurrent CSV modification detected')
    replace_verified(temporary, SOURCE)
    saved_headers, saved = read_csv(SOURCE)
    if saved_headers != headers or saved != after:
        raise RuntimeError('Post-write verification failed')
    statuses = dict(Counter(row['absa_status'] for row in saved))
    audit = {**payload, 'completed_at': datetime.now(timezone.utc).isoformat(),
             'changed_rows': changed, 'output_sha256': sha(SOURCE.read_bytes()),
             'status_counts': statuses}
    write_json(audit_path, audit)
    state['batches'].append({'first_id': first, 'last_id': last, 'count': changed,
                             'audit': str(audit_path)})
    state['direct_rows'] += changed
    state['status_counts'] = statuses
    state['updated_at'] = audit['completed_at']
    write_json(state_path, state)
    print(json.dumps({'changed_rows': changed, 'first_id': first, 'last_id': last,
                      'empty_labels': sum(not r['gemini_label'] for r in records),
                      'statuses': statuses, 'audit': str(audit_path)}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['select', 'prepare', 'commit'])
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--decisions', type=Path)
    parser.add_argument('--payload', type=Path)
    parser.add_argument('--limit', type=int, default=100)
    args = parser.parse_args()
    if args.mode == 'select':
        if not args.snapshot or not 1 <= args.limit <= 100:
            parser.error('select requires --snapshot and limit 1..100')
        select(args.snapshot, args.limit)
    elif args.mode == 'prepare':
        if not args.snapshot or not args.decisions or not args.payload:
            parser.error('prepare requires --snapshot, --decisions, --payload')
        prepare(args.snapshot, args.decisions, args.payload)
    else:
        if not args.payload:
            parser.error('commit requires --payload')
        commit(args.payload)


if __name__ == '__main__':
    main()
