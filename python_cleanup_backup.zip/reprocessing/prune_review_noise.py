"""Remove the approved 40 noise + 3 ambiguous groups and archive old CSV reports.

Run without arguments to preview; --apply saves a verified ZIP before changes.
Keeps ABSA IDs stable and updates source record positions in the mapping.
"""

import argparse
import csv
import hashlib
import io
import json
import os
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from create_unique_text_dataset import normalize_text_key, text_group_id


ROOT = Path(__file__).resolve().parent.parent
LABELED = ROOT / "Labeling/data/unique_texts_gemini_labeled.csv"
SOURCE = ROOT / "crawl-data/data/combined_reviews_brand_filled_language_filtered.csv"
UNIQUE = ROOT / "crawl-data/data/unique_texts/unique_texts.csv"
MAPPING = UNIQUE.with_name("review_text_mapping.csv")
AUDIT = LABELED.with_name("empty_label_review_audit.csv")
ARCHIVE = ROOT / "data_cleanup_backup.zip"
LOG = ROOT / "data_cleanup_log.json"


def safe(path):
    resolved = path.resolve()
    if not resolved.is_relative_to(ROOT) or resolved == ROOT:
        raise ValueError(f"Path outside workspace: {path}")
    return resolved


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(raw):
    lines = raw.decode("utf-8-sig").splitlines(keepends=True)
    reader = csv.reader(lines)
    records, chunks, start = [], [], 0
    for record in reader:
        records.append(record)
        chunks.append("".join(lines[start:reader.line_num]).encode("utf-8"))
        start = reader.line_num
    if raw.startswith(b"\xef\xbb\xbf"):
        chunks[0] = b"\xef\xbb\xbf" + chunks[0]
    header = records[0]
    assert len(header) == len(set(header))
    assert all(len(row) == len(header) for row in records[1:])
    return header, [dict(zip(header, row)) for row in records[1:]], chunks


def filtered_bytes(header, rows, chunks, replacements):
    result = [chunks[0]]
    for index, old in enumerate(rows, 1):
        new = replacements.get(index, old)
        if new is None:
            continue
        if old == new:
            result.append(chunks[index])
            continue
        stream = io.StringIO(newline="")
        ending = "\r\n" if chunks[index].endswith(b"\r\n") else "\n"
        writer = csv.DictWriter(stream, fieldnames=header, quoting=csv.QUOTE_ALL, lineterminator=ending)
        writer.writerow(new)
        result.append(stream.getvalue().encode("utf-8"))
    return b"".join(result)


def prepare(approved=None, cleanup_reports=True):
    files = {path: safe(path).read_bytes() for path in (LABELED, SOURCE, UNIQUE, MAPPING)}
    if approved is None:
        files[AUDIT] = safe(AUDIT).read_bytes()
        _, audit, _ = read(files[AUDIT])
        approved = [r for r in audit if r["review_action"] in ("deletion_candidate", "needs_review")]
        assert Counter(r["review_action"] for r in approved) == {"deletion_candidate": 40, "needs_review": 3}
    assert approved
    groups = {r["text_group_id"] for r in approved}
    assert len(groups) == len(approved)
    parsed = {p: read(files[p]) for p in (LABELED, SOURCE, UNIQUE, MAPPING)}
    lh, labeled, lc = parsed[LABELED]
    sh, source, sc = parsed[SOURCE]
    uh, unique, uc = parsed[UNIQUE]
    mh, mapping, mc = parsed[MAPPING]
    assert len(source) == len(mapping)
    assert [{k: r[k] for k in uh} for r in labeled] == unique
    by_group = {r["text_group_id"]: r for r in labeled}
    assert len(by_group) == len(labeled)
    for row in approved:
        current = by_group[row["text_group_id"]]
        assert current["absa_row_id"] == row["absa_row_id"]
        assert current["cleaned_comment"] == row["cleaned_comment"] and current["gemini_label"] == ""
    sr, mr, retained_source, retained_mapping = {}, {}, [], []
    first_positions, counts = {}, Counter()
    for index, (row, mapped) in enumerate(zip(source, mapping), 1):
        assert all(row[k] == mapped[k] for k in sh)
        assert mapped["source_row"] == str(index)
        text = normalize_text_key(row["cleaned_comment"])
        group = text_group_id(text) if text else ""
        assert group == mapped["text_group_id"]
        if group in groups:
            sr[index] = mr[index] = None
            continue
        retained_source.append(row)
        updated = {**mapped, "source_row": str(len(retained_source))}
        mr[index] = updated
        retained_mapping.append(updated)
        if group:
            first_positions.setdefault(group, str(len(retained_source)))
            counts[group] += 1
    assert len(source) - len(retained_source) == sum(int(r["duplicate_count"]) for r in approved)
    replacements = {SOURCE: sr, MAPPING: mr}
    expected = {SOURCE: retained_source, MAPPING: retained_mapping}
    for path, rows in ((UNIQUE, unique), (LABELED, labeled)):
        updates, kept = {}, []
        for index, row in enumerate(rows, 1):
            group = row["text_group_id"]
            if group in groups:
                updates[index] = None
                continue
            assert int(row["duplicate_count"]) == counts[group]
            updated = {**row, "representative_source_row": first_positions[group]}
            updates[index] = updated
            kept.append(updated)
        assert len(rows) - len(kept) == len(groups)
        replacements[path], expected[path] = updates, kept
    output = {}
    for path, (header, rows, chunks) in parsed.items():
        data = filtered_bytes(header, rows, chunks, replacements[path])
        after_header, after, _ = read(data)
        assert after_header == header and after == expected[path]
        output[path] = data
    assert all(r["absa_status"] == "done" for r in expected[LABELED])
    assert [{k: r[k] for k in uh} for r in expected[LABELED]] == expected[UNIQUE]
    assert not groups.intersection(r["text_group_id"] for r in expected[MAPPING])
    summary_path = UNIQUE.with_name("deduplication_summary.json")
    readme_path = UNIQUE.with_name("README.md")
    for path in (summary_path, readme_path):
        files[path] = safe(path).read_bytes()
    summary = json.loads(files[summary_path].decode("utf-8-sig"))
    previous = summary.copy()
    nonempty = sum(counts.values())
    summary.update({
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": sha(output[SOURCE]), "input_rows": len(retained_source),
        "nonempty_text_rows": nonempty, "empty_text_rows": len(retained_source) - nonempty,
        "unique_texts": len(counts), "duplicate_excess_rows": nonempty - len(counts),
        "repeated_text_groups": sum(n > 1 for n in counts.values()),
        "output_sha256": {p.name: sha(output[p]) for p in (UNIQUE, MAPPING)},
        "manual_cleanup_log": str(LOG.relative_to(ROOT)),
    })
    output[summary_path] = (json.dumps(summary, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    readme = files[readme_path].decode("utf-8-sig")
    for key in ("input_rows", "nonempty_text_rows", "unique_texts", "duplicate_excess_rows", "empty_text_rows"):
        readme = readme.replace(f"{previous[key]:,}", f"{summary[key]:,}")
    output[readme_path] = readme.encode("utf-8")
    cleanup = set()
    if cleanup_reports:
        cleanup.update((ROOT / "crawl-data/analysis_output").rglob("*.csv"))
        for directory in (ROOT / "Labeling/data", ROOT / "crawl-data/data"):
            cleanup.update(directory.glob("*.before*.csv"))
            cleanup.update(directory.glob("*.before*.bak"))
        cleanup.update(LABELED.with_name(name) for name in (
            "empty_label_review_audit.csv", "empty_label_deletion_candidates.csv", "empty_label_needs_review.csv"))
    assert not cleanup.intersection(output)
    cleanup = sorted(safe(p) for p in cleanup)
    for path in cleanup:
        files[path] = path.read_bytes()
    manifest = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "removed_absa_row_ids": [r["absa_row_id"] for r in approved],
        "removed_text_group_ids": sorted(groups),
        "removed_records": {str(p.relative_to(ROOT)): len(parsed[p][1]) - len(expected[p]) for p in parsed},
        "remaining_records": {str(p.relative_to(ROOT)): len(expected[p]) for p in parsed},
        "remaining_empty_labels": sum(not r["gemini_label"] for r in expected[LABELED]),
        "deleted_csv_or_old_backup_files": [str(p.relative_to(ROOT)) for p in cleanup],
        "backup_zip": str(ARCHIVE.relative_to(ROOT)),
        "before_sha256": {str(p.relative_to(ROOT)): sha(data) for p, data in files.items()},
        "after_sha256": {str(p.relative_to(ROOT)): sha(data) for p, data in output.items()},
        "stable_absa_ids_preserved": True,
        "source_row_positions_rebased": True,
        "surviving_labels_and_source_values_preserved": True,
    }
    return files, output, cleanup, manifest


def finish_cleanup(manifest):
    with zipfile.ZipFile(ARCHIVE) as archive:
        if "test_csv_cleanup_manifest.json" in archive.namelist():
            extra = json.loads(archive.read("test_csv_cleanup_manifest.json"))
            for name, digest in extra.items():
                assert sha(archive.read(Path(name).as_posix())) == digest
                if name not in manifest["deleted_csv_or_old_backup_files"]:
                    manifest["deleted_csv_or_old_backup_files"].append(name)
                manifest["before_sha256"][name] = digest
    assert all(sha(safe(ROOT / name).read_bytes()) == digest
               for name, digest in manifest["after_sha256"].items())
    blocked = []
    for name in manifest["deleted_csv_or_old_backup_files"]:
        path = safe(ROOT / name)
        if not path.exists():
            continue
        assert sha(path.read_bytes()) == manifest["before_sha256"][name]
        try:
            path.unlink()
        except PermissionError:
            blocked.append(name)
    manifest["cleanup_files_still_locked"] = blocked
    manifest["cleanup_complete"] = not blocked
    safe(LOG).write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cleanup_complete": not blocked, "locked_files": blocked}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--resume-cleanup", action="store_true", help="Retry deleting files locked by another app")
    args = parser.parse_args()
    if args.resume_cleanup:
        with zipfile.ZipFile(safe(ARCHIVE)) as archive:
            assert archive.testzip() is None
            manifest = json.loads(archive.read("cleanup_manifest.json"))
            for name, digest in manifest["before_sha256"].items():
                assert sha(archive.read(Path(name).as_posix())) == digest
        finish_cleanup(manifest)
        return
    files, output, cleanup, manifest = prepare()
    print(json.dumps({k: manifest[k] for k in (
        "removed_records", "remaining_records", "remaining_empty_labels")}, ensure_ascii=False))
    print(f"Old CSV/backup files to remove: {len(cleanup)}")
    if not args.apply:
        return
    assert not ARCHIVE.exists() and not LOG.exists(), "Cleanup already run; inspect current state"
    with zipfile.ZipFile(safe(ARCHIVE), "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, data in files.items():
            archive.writestr(path.relative_to(ROOT).as_posix(), data)
        archive.writestr("cleanup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        for path, data in files.items():
            assert archive.read(path.relative_to(ROOT).as_posix()) == data
    assert all(path.read_bytes() == data for path, data in files.items()), "Files changed during preparation"
    for path, data in output.items():
        temporary = safe(path.with_name(path.name + ".cleanup.tmp"))
        temporary.write_bytes(data)
        os.replace(temporary, safe(path))
    assert all(path.read_bytes() == data for path, data in output.items())
    # Delete only individually verified files inside this workspace, after backup.
    finish_cleanup(manifest)


if __name__ == "__main__":
    main()
